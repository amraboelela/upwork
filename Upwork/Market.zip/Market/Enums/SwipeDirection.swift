//
//  SwipeDirection.swift
//  Common
//
//  Created by Amr Aboelela on 3/30/24.
//

import Foundation

enum SwipeDirection {
    case up, down, left, right, none
}
